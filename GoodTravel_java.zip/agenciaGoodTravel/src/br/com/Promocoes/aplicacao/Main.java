package br.com.Promocoes.aplicacao;

import br.com.Promocoes.dao.PromocaoDAO;
import br.com.Promocoes.model.Promocao;

public class Main {
	
public static void main(String[] args) {
		
		PromocaoDAO promocaoDao = new PromocaoDAO();
		
		Promocao promocao = new Promocao();
		promocao.setNome("Black Friday");
		promocao.setValorPromo(500);
		promocao.setIdDestino(0);;
		
		promocaoDao.save(promocao);
		
		//Atualizar o destino.
		Promocao p1 = new Promocao();
		p1.setNome("Aniversario");
		p1.setValorPromo(0);;
		p1.setIdDestino(0);;
		p1.setIdPromo(4);
		
		promocaoDao.update(p1);
		
		//Deletar o destino pelo seu número de ID.
		promocaoDao.removeById(4);
		
		for(Promocao c : promocaoDao.getPromocoes()) {
			System.out.println("Promoção: "+c.getNome());
		}
		

	}

}
