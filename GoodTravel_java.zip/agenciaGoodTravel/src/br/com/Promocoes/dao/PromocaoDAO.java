package br.com.Promocoes.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.Promocoes.model.Promocao;
import br.com.GoodTravel.factory.ConnectionFactory;

public class PromocaoDAO {
	
	public void save(Promocao promocao) {
		
		String sql = "INSERT INTO promocoes(nome, valorPromo, idDestino) VALUES (?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, promocao.getNome());
			pstm.setFloat(2, promocao.getValorPromo());
			pstm.setInt(3, promocao.getIdDestino());
			
			pstm.execute();
			
			System.out.println("Promoção salva com sucesso!");
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			
			try {
				if(pstm != null) {
					pstm.close();
				}
				
				if(conn != null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	public void update(Promocao promocao) {
		
		String sql = "UPDATE promocoes SET nome = ?, valorPromo = ?, idDestino = ?"+ "WHERE idPromo = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1, promocao.getNome());
			pstm.setFloat(2, promocao.getValorPromo());
			pstm.setInt(3, promocao.getIdDestino());
			
			pstm.setInt(4, promocao.getIdPromo());
			
			pstm.execute();
			
			System.out.println("Promoção alterada com sucesso!");
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				
				if(conn != null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	public void removeById( int idPromo) {
		String sql = "DELETE FROM promocoes WHERE idPromo = ?";
		
		Connection conn = null;
		
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			
			pstm.setInt(1, idPromo);
			
			pstm.execute();
			
			System.out.println("Promoção removida!");
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				
				if(conn != null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Promocao> getPromocoes(){
		
		String sql = "SELECT * FROM promocoes";
		
		List<Promocao> promocoes = new ArrayList<Promocao>();
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		ResultSet rset = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();
			
			while (rset.next()) {
				
				Promocao promocao = new Promocao();
				
				promocao.setIdPromo(rset.getInt("idPromo"));
				promocao.setNome(rset.getString("nome"));
				promocao.setValorPromo(rset.getFloat("valorPromo"));
				promocao.setIdDestino(rset.getInt("idDestino"));
				
				promocoes.add(promocao);
				
			}
				
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					if(rset != null) {
						rset.close();
						
					}
					
					if(pstm != null) {
						pstm.close();
					}
					
					if(conn != null) {
						conn.close();
					}
					
				}catch(Exception e) {
					e.printStackTrace();
				}
				
			}
			
			return promocoes;
		}

}
