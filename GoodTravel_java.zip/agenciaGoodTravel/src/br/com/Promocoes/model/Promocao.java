package br.com.Promocoes.model;

public class Promocao {
	
	private int idPromo;
	private String nome;
	private float valorPromo;
	private int idDestino;
	
	public int getIdDestino() {
		return idDestino;
	}
	public void setIdDestino(int idDestino) {
		this.idDestino = idDestino;
	}
	public int getIdPromo() {
		return idPromo;
	}
	public void setIdPromo(int idPromo) {
		this.idPromo = idPromo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getValorPromo() {
		return valorPromo;
	}
	public void setValorPromo(float valorPromo) {
		this.valorPromo = valorPromo;
	}

	
}
	
