package br.com.Destinos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.Destinos.model.Destino;
import br.com.GoodTravel.factory.ConnectionFactory;

public class DestinoDAO {
	
	
	public void save(Destino destino) {
	
		String sql = "INSERT INTO destinos(nome, estado, pais, dataIda, dataVolta, valor) VALUES (?, ?, ?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, destino.getNome());
			pstm.setString(2, destino.getEstado());
			pstm.setString(3, destino.getPais());
			pstm.setString(4, destino.getDataIda());
			pstm.setString(5, destino.getDataVolta());
			pstm.setFloat(6, destino.getValor());
			
			pstm.execute();
			
			System.out.println("Destino salvo com sucesso!");
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			
			try {
				if(pstm != null) {
					pstm.close();
				}
				
				if(conn != null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	public void update(Destino destino) {
		
		String sql = "UPDATE destinos SET nome = ?, estado = ?, pais = ?, dataIda = ?, dataVolta = ?, valor = ?"+ "WHERE idDestino = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1, destino.getNome());
			pstm.setString(2, destino.getEstado());
			pstm.setString(3, destino.getPais());
			pstm.setString(4, destino.getDataIda());
			pstm.setString(5, destino.getDataVolta());
			pstm.setFloat(6, destino.getValor());
			
			pstm.setInt(7, destino.getIdDestino());
			
			pstm.execute();
			
			System.out.println("Destino alterado com sucesso!");
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				
				if(conn != null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	public void removeById( int idDestino) {
		String sql = "DELETE FROM destinos WHERE idDestino = ?";
		
		Connection conn = null;
		
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			
			pstm.setInt(1, idDestino);
			
			pstm.execute();
			
			System.out.println("Destino removido!");
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				
				if(conn != null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Destino> getDestinos(){
		
		String sql = "SELECT * FROM destinos";
		
		List<Destino> destinos = new ArrayList<Destino>();
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		ResultSet rset = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();
			
			while (rset.next()) {
				
				Destino destino = new Destino();
				
				destino.setIdDestino(rset.getInt("idDestino"));
				destino.setNome(rset.getString("nome"));
				destino.setEstado(rset.getString("estado"));
				destino.setPais(rset.getString("pais"));
				destino.setDataIda(rset.getString("dataIda"));
				destino.setDataVolta(rset.getString("dataVolta"));
				destino.setValor(rset.getFloat("valor"));
				
				destinos.add(destino);
				
			}
				
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					if(rset != null) {
						rset.close();
						
					}
					
					if(pstm != null) {
						pstm.close();
					}
					
					if(conn != null) {
						conn.close();
					}
					
				}catch(Exception e) {
					e.printStackTrace();
				}
				
			}
			
			return destinos;
		}	
}
