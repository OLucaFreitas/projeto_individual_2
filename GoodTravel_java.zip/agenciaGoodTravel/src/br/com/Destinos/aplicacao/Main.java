package br.com.Destinos.aplicacao;

import br.com.Destinos.dao.DestinoDAO;
import br.com.Destinos.model.Destino;

public class Main {

	public static void main(String[] args) {
		
		DestinoDAO destinoDao = new DestinoDAO();
		
		Destino destino = new Destino();
		destino.setNome("Gramado");
		destino.setEstado("RS");
		destino.setPais("Brasil");
		destino.setDataIda("22-09-2022");
		destino.setDataVolta("31-10-22");
		destino.setValor(60000);
		
		destinoDao.save(destino);
		
		//Atualizar o destino.
		Destino d1 = new Destino();
		d1.setNome("Gramado");
		d1.setEstado("RS");
		d1.setPais("Brasil");
		d1.setDataIda("22-09-2022");
		d1.setDataVolta("31-10-22");
		d1.setValor(472);
		d1.setIdDestino(4);
		
		destinoDao.update(d1);
		
		//Deletar o destino pelo seu número de ID.
		destinoDao.removeById(4);
		
		for(Destino c : destinoDao.getDestinos()) {
			System.out.println("Destino: "+c.getNome());
		}
		

	}

	

		
	}
