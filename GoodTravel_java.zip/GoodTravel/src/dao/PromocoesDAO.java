package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PromocoesDAO {
	
	private Connection connection;
    
    public PromocoesDAO() {
        this.connection = new ConnectionFactory().getConnection();
    }
    
    public void save(Promocoes promocoes) {
        String sql = "INSERT INTO promocoes VALUES (?,?,?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, promocoes.getIdPromo());
            stmt.setString(2, promocoes.getNome());
            stmt.setFloat(3, promocoes.getValorPromo());
            stmt.execute();
            stmt.close();    
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    
    public void removeById(int idPromo) {
        String sql = "DELETE FROM promocoes WHERE idPromo= ?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, idPromo);
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    
    public void update(Promocoes promocoes) {
        String sql = "UPDATE promocoes SET nome = ?, valorPromo = ? WHERE idPromo = ?";
        
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, promocoes.getNome());
            stmt.setFloat(2, promocoes.getValorPromo());
            stmt.setInt(3, promocoes.getIdPromo());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
    }
    
    public ResultSet getPromocoes() throws SQLException {
        String sql = "SELECT * FROM promocoes";
        Statement stmt = null;
        ResultSet resultado = null;
        try {
            stmt = connection.createStatement();
            resultado =  stmt.executeQuery(sql);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return resultado;
        
    }
}
