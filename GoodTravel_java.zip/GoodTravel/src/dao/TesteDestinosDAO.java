package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TesteDestinosDAO {

	   public static void main(String[] args) {
	        // Testando a execução da Destinos DAO
	        Destinos destinos = new Destinos();
	        
	        destinos.setIdDestino(1);
	        destinos.setNome("São Paulo");
	        destinos.setEstado("SP");
	        destinos.setPais("Brasil");
	        destinos.setDataIda("02/09");
	        destinos.setDataVolta("31/10");
	        destinos.setValor(479);
	        
	        DestinosDAO dao = new DestinosDAO();
	        
	        dao.save(destinos);
	        System.out.println("Destino salvo!");
	        
	        DestinosDAO dao2 = new DestinosDAO();
	        dao2.removeById(1);
	        System.out.println("Destino removido!");
	        
	        destinos.setNome("São Paulo");
	        destinos.setIdDestino(1);
	        dao.update(destinos);
	        System.out.println("Destino alterado");
	        
	        
	        try {
	            ResultSet resultado= dao.getDestinos();
	            while (resultado.next()) {
	               System.out.println(resultado.getInt(1));
	                System.out.println(resultado.getString(2));
	               System.out.println(resultado.getString(3));
	               System.out.println(resultado.getString(4));
	               System.out.println(resultado.getString(5));
	               System.out.println(resultado.getString(6));
	               System.out.println(resultado.getFloat(7));
	            }
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        
	    }
}
