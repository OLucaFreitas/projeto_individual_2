package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DestinosDAO {

	    private Connection connection;
	    
	    public DestinosDAO() {
	        this.connection = new ConnectionFactory().getConnection();
	    }
	    
	    public void save (Destinos destinos) {
	        String sql = "INSERT INTO destinos VALUES (?,?,?,?,?,?,?)";
	        try {
	            PreparedStatement stmt = connection.prepareStatement(sql);
	            stmt.setInt(1, destinos.getIdDestino());
	            stmt.setString(2, destinos.getNome());
	            stmt.setString(3, destinos.getEstado());
	            stmt.setString(4, destinos.getPais());
	            stmt.setString(5, destinos.getDataIda());
	            stmt.setString(6, destinos.getDataVolta());
	            stmt.setFloat(7, destinos.getValor());
	            stmt.execute();
	            stmt.close();    
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        
	    }
	    
	    public void removeById(int idDestino) {
	        String sql = "DELETE FROM destinos WHERE idDestino= ?";
	        try {
	            PreparedStatement stmt = connection.prepareStatement(sql);
	            stmt.setInt(1, idDestino);
	            stmt.execute();
	            stmt.close();
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        
	    }
	    
	    public void update(Destinos destinos) {
	        String sql = "UPDATE destinos SET nome = ?, estado = ?, pais = ?, dataIda = ?, dataVolta = ?, valor = ? WHERE idDestino = ?";
	        
	        try {
	            PreparedStatement stmt = connection.prepareStatement(sql);
	            stmt.setString(1, destinos.getNome());
	            stmt.setString(2, destinos.getEstado());
	            stmt.setString(3, destinos.getPais());
	            stmt.setString(4, destinos.getDataIda());
	            stmt.setString(5, destinos.getDataVolta());
	            stmt.setFloat(6, destinos.getValor());
	            stmt.setInt(7, destinos.getIdDestino());
	            stmt.execute();
	            stmt.close();
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        
	        
	    }
	    
	    public ResultSet getDestinos() throws SQLException {
	        String sql = "SELECT * FROM destinos";
	        Statement stmt = null;
	        ResultSet resultado = null;
	        try {
	            stmt = connection.createStatement();
	            resultado =  stmt.executeQuery(sql);
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        return resultado;
	        
	    }


}
