package dao;

public class Promocoes {
	
	private int idPromo;
	private String nome;
	private float valorPromo;
	
	
	public int getIdPromo() {
		return idPromo;
	}
	public void setIdPromo(int idPromo) {
		this.idPromo = idPromo;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public float getValorPromo() {
		return valorPromo;
	}
	
	public void setValorPromo(float valorPromo) {
		this.valorPromo = valorPromo;
	}

}
