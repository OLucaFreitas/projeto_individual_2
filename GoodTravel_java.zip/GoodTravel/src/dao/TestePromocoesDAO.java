package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TestePromocoesDAO {
	
	public static void main(String[] args) {
        // Testando a execução da Promocoes DAO
		
        Promocoes promocoes = new Promocoes();
        
        promocoes.setIdPromo(0);
        promocoes.setNome("Black Friday");
        promocoes.setValorPromo(517);
        
        PromocoesDAO dao = new PromocoesDAO();
        
        dao.save(promocoes);
        System.out.println("Promoção salva!");
        
        PromocoesDAO dao2 = new PromocoesDAO();
        dao2.removeById(2);
        System.out.println("Promoção removida!");
        
        promocoes.setValorPromo(0);
        promocoes.setNome("31/11");
        promocoes.setIdPromo(1);
        dao.update(promocoes);
        System.out.println("Promoção alterada");
        
        
        try {
            ResultSet resultado= dao.getPromocoes();
            while (resultado.next()) {
               System.out.println(resultado.getInt(1));
               System.out.println(resultado.getString(2));
               System.out.println(resultado.getFloat(3));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }

}
